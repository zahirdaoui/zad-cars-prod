var spanDate = document.getElementById('yearCopyRight');
let date =  new Date().getFullYear();

spanDate.innerHTML = date;
